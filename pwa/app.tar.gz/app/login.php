<!DOCTYPE html>
<html lang="pt">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="MKTOP CLIENTE">
    <meta name="keywords" content="SISTEMA DE ATENDIMENTO AO CLIENTE">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no" name="viewport" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <title>CLIENTE SUPORTE</title>
    
    <!-- bootstrap 4.3.1 -->
    <link rel="stylesheet" href="css/bootstrap.css">

    <!-- font awesome 6.1.1 -->
    <link rel="stylesheet" href="css/all.min.css"/>
    
    <script type="text/javascript" async="" src="js/ga.js"></script>

    <link rel="manifest" href="./manifest.json"/>

    <link rel="preload" href="./app.js" as="script"/>
    
    <link rel="apple-touch-icon" sizes="76x76" href="icons/icons-app/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" href="icons/icons-app/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="152x152" href="icons/icons-app/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="icons/icons-app/apple-touch-icon-180x180.png">
    <link rel="apple-touch-icon" sizes="167x167" href="icons/icons-app/apple-touch-icon-167x167.png">
    <!-- tela splash -->
    <link href="icons/splash/apple_splash_2048.png" sizes="2048x2732" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1668.png" sizes="1668x2224" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1536.png" sizes="1536x2048" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1125.png" sizes="1125x2436" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1242.png" sizes="1242x2208" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_750.png" sizes="750x1334" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_640.png" sizes="640x1136" rel="apple-touch-startup-image" />

    <!-- iOS -->
    <link rel="apple-touch-icon" href="icons/icons-app/apple-touch-icon-144x144.png"/>
    <meta name="mobile-web-app-capable" content="yes"/>
    <meta name="mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="mobile-web-app-title" content="MKTOP CLIENTE"/>
    <meta property="og:title" content="Castanhal - Pará - Brasil"/>
    <meta property="og:description" content="MKTOP CLIENTE"/>
    <meta property="og:image" content="icons/icons-app/icon-192x192.png"/>
    <meta property="og:url" content="https://mktop.net/pwa/"/>
    <meta property="og:type" content="website"/>
    <meta name="twitter:creator" property="og:site_name" content="@msulibrary"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:site" content="https://mktop.net/pwa/"/>

    <!-- Favicon icon -->
    <link rel="shortcut icon" type="image/png" href="icons/logo.png">
    <link rel="icon" type="image/png" href="icons/icons-app/icon-96x96.png">
    <link rel="apple-touch-icon" href="icons/icons-app/icon-96x96.png">
</head>
<style>
/*

@media screen and (min-device-width: 480px) {
    body {
        display: none;
    }
}
*/
  </style>
<body style="background:white !important;">
<header class="header" role="banner">
  <h3 CLASS="text_header">MKTOP CLIENTE</h3>
  </header>
    <div class="container py-5 h-100">
    <div class="row d-flex align-items-center justify-content-center h-100">
      <div class="col-md-8 col-lg-7 col-xl-6">
        <img src="../acesso/dist/img/logo_jpg.jpg"
          class="img-fluid" alt="Phone image">
      </div>
    <form method="post" id="valida-form" autocomplete="off">
<div class="row">
    <div class="col-lg-12">
        <div class="col-12"><center>
        <label for="inputDefault"><h2 class="label_text">CPF/CNPJ</h2></label>
        <input type="number" class="form-control form-control-lg" id="acesso" name="acesso" placeholder="Apenas números" style="text-align:center;" required>
        <label for="inputDefault"><h2 class="label_text">DATA DE NASCIMENTO</h2></label></center>
        <input type="tel" class="form-control form-control-lg data" name="data" placeholder="dd-mm-aa"  style="text-align:center;" required>
      </div>
    <div class="col-12">
    <label for="inputDefault"></label>
<button type="submit" class="btn btn-info btn-block btn-lg btn_login" id="btn2">ENTRAR</button>
</div>
    <br />
      <div class="col-12">
        <label for="inputDefault"><h4 style="font-family: bebas;">Lembrar login </h4></label>
        <input type="checkbox" class="input-checkbox" name="lembrete" value="SIM" style="width: 20px;
        height: 20px;"/>
      </div>
      <div class="col-12" id="error">
</div>
    </div>
</div>
</form>
</div>
</div>

</body>
<!-- jQuery 3 -->
<script src="../acesso/bower_components/jquery/dist/jquery.min.js"></script>
<!-- mascaras -->
<script src="../acesso/dist/js/jquery.mask.js"></script>
<script src="../acesso/dist/js/meusscripts.js"></script>
<script src="./app.js" ></script>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>
<!-- font awesome 6.1.1 js -->
<script src="js/all.min.js"></script>
<script>
    $('#valida-form').submit(function(){ 
        $('#btn2').html('Aguarde, Processando...');
        $.ajax({
            type:'post',
            url:'valida-cliente.php',
            data:$('#valida-form').serialize(),
            success:function(data){
                $('#btn2').show().html('ENTRAR');
                $('#error').show().fadeOut(5000).html(data);                
            }
        });
        return false;
    });
</script>
</html>