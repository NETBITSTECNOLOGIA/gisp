<?php
session_start();
include('conexao.php');
include('../acesso/funcoes.php');
@$idcliente = (isset($_COOKIE['idcliente'])) ? $_COOKIE['idcliente'] : '';
@$idempresa = (isset($_COOKIE['idempresa'])) ? $_COOKIE['idempresa'] : '';
@$nomecliente = (isset($_COOKIE['nomecliente'])) ? $_COOKIE['nomecliente'] : '';

//nchamado,idcliente,idempresa,nomecliente,tipo,usuariocad,datacad,obs,situacao
@$tipo = strtoupper(@$_POST['tipo']);
@$obs = AspasBanco(@$_POST['obs']);
@$nchamado = $idcliente.date('dmYHms');

if(!empty(@$idempresa) AND !empty(@$tipo) AND !empty(@$obs)){
    mysqli_query($conexao,"INSERT INTo chamado 
    (nchamado,idcliente,idempresa,nomecliente,tipo,usuariocad,datacad,obs,situacao) 
    VALUES ('$nchamado','$idcliente','$idempresa','$nomecliente','$tipo','$nomecliente',NOW(),'$obs','ABERTO')
    ") or die (mysqli_error($conexao));

    echo "<script>alert('chamado aberto com sucesso!')</script>";
    echo "<script>window.location.href='chamado.php';</script>";
}else{
    echo "<script>window.location.href='abrir-chamado.php';</script>";
}