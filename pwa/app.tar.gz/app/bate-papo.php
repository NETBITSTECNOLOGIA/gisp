<?php
include 'topo.php';
echo'
  
<div class="row" style="font-size: 14px; margin: 8px; margin-top: -40px";>
    <div class="col-lg-12">
    <div class="page-header">
    <h3>BATE PAPO</h3>
</div>
<div>
<div class="alert alert-success">
  <p>Fulano de tal</p>
  <p>Minha internet não ta funcionado, poderia verificar por que não está??</p>
</div>

<div class="alert alert-primary" style="text-align:right;">
  <p>Suporte</p>
  <p>Pague sua fatura seu caloteiro do karai !!!!</p>
</div>

<div class="alert alert-success">
  <p>Fulano de tal</p>
  <p>Mas eu paguei adiantado o mês</p>
</div>

<div class="alert alert-primary" style="text-align:right;">
  <p>Suporte</p>
  <p>Desculpe senhor, era outro caloteiro. O senha aceita um café?? ;)</p>
</div>


<input type="text" class="form-control" placeholder="Digite aqui"/>
<br />
<button type="submit" class="btn btn-primary">Enviar</button>



</div>
</div>
</div>
</div>
</div>
<br />
<div class="row">
<div class="col-lg-12">
<center>
<a href="index.php">
<img src="icons/voltar.png" style="width: 30px"/>
<br />
<small style="color:black">VOLTAR</small>
</a>
</center>
</div>
</div>



';
include 'rodape.php';
?>