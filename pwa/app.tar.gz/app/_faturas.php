<?php
include 'topo.php';
echo'
            <div class="row" style="font-size: 12px; margin: 2px";>
                <div style="text-align:center;" class="col-lg-12">
                  <div class="page-header" style="text-align:center;">
                    <h3 style="margin-top:1em">FATURAS</h3>
                  </div>
               <div>
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">Valor</th>
                    <th scope="col">Vencimento</th>
                    <th scope="col">#</th>
                  </tr>
                </thead>
                <tbody>';
                $query0 = mysqli_query($conexao,"SELECT * FROM cobranca WHERE idcliente='$idcliente' ORDER BY id DESC") or die (mysqli_error($conexao));             
                if($rows = mysqli_num_rows($query0) >= 1){
                  while ($ddc = mysqli_fetch_array($query0)) { 
                    if($ddc['situacao'] ==  'RECEBIDO'){
                      echo'
                      <tr class="table-success">
                        <td>R$ '.Real($ddc['valor']).'</td>
                        <td>'.date('d-m-Y',strtotime($ddc['vencimento'])).'</td>
                        <td><a href="#"><img src="icons/pago.png" width="20px"/></a></td>
                      </tr>';
                      }elseif($ddc['tipo'] == 'Boleto' && $ddc['tipo'] == 'Boleto_pix'){
                       echo'
                      <tr class="table-danger">
                        <td>R$ '.Real($ddc['valor']).'</td>
                        <td>'.date('d-m-Y',strtotime($ddc['vencimento'])).'</td>
                        <td><a href="'.$ddc['link'].'" style="color:black"><img src="icons/baixar.png" width="20px"/> Boleto</a><br />
                        </td>
                      </tr>';
                      }elseif($ddc['tipo'] == 'Manual'){
                        echo'
                      <tr class="table-danger">
                        <td>R$ '.Real($ddc['valor']).'</td>
                        <td>'.date('d-m-Y',strtotime($ddc['vencimento'])).'</td>
                        <td>
                          <a href="../acesso/carne/carne.php?id='.$ddc['id'].'" target="_blank"><img src="icons/novo.png" width="20px"/></a> &emsp;
                          <a href="../acesso/carne/carnes.php?id='.$ddc['idcobrancaprincipal'].'" target="_blank"><img src="icons/relatorio.png" width="20px"/></a>
                        </td>
                      </tr>';
                    }
                  }
                }else{
                  echo'Sem cobrança;';
                              }
                echo'
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
        <br/>
            <div class="row">
                <div class="col-lg-12">
                  <center>
                    <div class="page-header" style="text-align:center;">
                      <h3 style="margin-top:0em">LEGENDAS</h3>
                        <i style="color:red">
                        <i style="color:#0d972c" class="fa-solid fa-circle"></i>: FATURA PAGA<br />
                        <i style="color:#0056a1" class="fa-solid fa-circle"></i>: PENDENTE OU ABERTO<br />
                        <i style="color:red" class="fa-solid fa-circle"></i>: VENCIDO OU NÃO PAGO
                        </i>
                    </center>
                  </div>
                </div>
             <br>
          ';
include 'rodape.php';
?>