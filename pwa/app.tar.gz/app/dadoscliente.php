<?php
include 'topo.php';
$query = mysqli_query($conexao,"SELECT cliente.*, plano.nomeservidor,plano.plano AS nomeplano,plano.valor, dadoscobranca.chavepixsecundaria 
FROM cliente 
LEFT JOIN plano ON cliente.plano = plano.id
LEFT JOIN dadoscobranca ON cliente.idempresa = dadoscobranca.idempresa
WHERE cliente.id=$_SESSION[idcliente] AND cliente.idempresa='$idempresa' AND plano.idempresa='$idempresa' AND dadoscobranca.idempresa='$idempresa'") or die (mysqli_error($conexao));
$dd = mysqli_fetch_array($query);
echo'
<style>
body{
  background: #ecf0f5 !important;
}
</style> 
  <div class="row" style="font-size: 14px";>
    <div style="text-align:center;" class="col-lg-12">
    <h3 style="margin-top:1em;background: #d9d9d9;border-radius: 0.2em;" class="title">DADOS DO CLIENTE</h3>
  <div style="text-align:center;">
  
  <div class="row">

      <div class="col-lg-4 col-md-12">
        <label for="inputDefault">Nome</label>
        <input type="text" class="form-control" value="'.$dd['nome'].'" placeholder="Fulado de tal" id="inputDefault" disabled="">
      </div>

      <div class="col-lg-3 col-md-12">
        <label for="inputDefault">CPF/CNPJ</label>
        <input type="text" class="form-control" value="';if($dd['cpf'] == ''){ echo $dd['cnpj'];}else{ echo $dd['cpf'];}echo'" id="inputDefault" disabled="">
      </div>


      <div class="col-lg-3 col-md-12">
        <label for="inputDefault">Nascimento</label>
        <input type="text" class="form-control" value="';if($dd['nascimento'] != ''){ echo dataForm($dd['nascimento']);}echo'" placeholder="00-00-0000" id="inputDefault" disabled="">
      </div>
      </div>


        <div class="row">
          <div class="col-lg-3 col-md-12">
            <label  for="inputDefault">Contato</label>
            <input type="text" class="form-control" value="'.$dd['contato'].'" placeholder="(00)00000-0000" id="inputDefault" disabled="">
          </div>

          <div class="col-lg-3 col-md-12">
            <label  for="inputDefault">Contato 2</label>
            <input type="text" class="form-control" value="'.$dd['contato2'].'" placeholder="(00)00000-0000" id="inputDefault" disabled="">
          </div>
        </div>
        
        <div class="row">
          <div class="col-lg-2 col-md-12">
            <label for="inputDefault">CEP</label>
            <input type="text" class="form-control" value="'.$dd['cep'].'" placeholder="00000-000" id="inputDefault" disabled="">
          </div>

          <div class="col-lg-4 col-md-12">
            <label for="inputDefault">Rua</label>
            <input type="text" class="form-control" value="'.$dd['rua'].'" placeholder="Av.Perdido, número 0" id="inputDefault" disabled="">
          </div>

        
          <div class="col-lg-2 col-md-12">
            <label for="inputDefault">Bairro</label>
            <input type="text" class="form-control" value="'.$dd['bairro'].'" placeholder="Bairro" id="inputDefault" disabled="">
          </div>

          <div class="col-lg-2 col-md-12">
            <label for="inputDefault">Município</label>
            <input type="text" class="form-control" value="'.$dd['municipio'].'" placeholder="Município" id="inputDefault" disabled="">
          </div>
        </div>
<hr>
  <div class="page-header"  style="text-align:center;">
  <h3 style="margin-top:1em;background: #d9d9d9;border-radius: 0.2em;" class="title">DADOS DO PLANO</h3>
  </div>
  <div class="row">
      <div class="col-lg-4 col-md-12">
        <label for="inputDefault">Situação do plano</label>
        <input type="text" class="form-control" value="'.$dd['situacao'].'" id="inputDefault" disabled="">
      </div>
      <div class="col-lg-4 col-md-12">
        <label for="inputDefault">Servidor</label>
        <input type="text" class="form-control" value="'.$dd['nomeservidor'].'" placeholder="Nome servidor" id="inputDefault" disabled="">
      </div>
      <div class="col-lg-4 col-md-12">
        <label for="inputDefault">Plano</label>
        <input type="text" class="form-control" value="'.$dd['nomeplano'].'" placeholder="Nome do plano" id="inputDefault" disabled="">
      </div>
      <div class="col-lg-4 col-md-12">
        <label for="inputDefault">Valor</label>
        <input type="text" class="form-control" value="R$ '.Real($dd['valor']).'" placeholder="Valor do plano" id="inputDefault" disabled="">
      </div>';
      if(!empty($dd['chavepixsecundaria'])){echo'
      <div class="col-lg-4 col-md-12">
        <label for="inputDefault">Click aqui para cópiar chave pix: </label>
        <input type="text" class="form-control" value="'.AspasForm($dd['chavepixsecundaria']).'" id="inputDefault" disabled=""/>
      </div>
  </div>
<br>'; }
include 'rodape.php';
?>