<?php
session_start();
include('../acesso/conexao.php');
include('../acesso/funcoes.php');
@$idcliente = (isset($_COOKIE['idcliente'])) ? $_COOKIE['idcliente'] : '';
@$idempresa = (isset($_COOKIE['idempresa'])) ? $_COOKIE['idempresa'] : '';
@$nomecliente = (isset($_COOKIE['nomecliente'])) ? $_COOKIE['nomecliente'] : '';
@$acesso = (isset($_COOKIE['acesso'])) ? $_COOKIE['acesso'] : '';
@$lembrete = (isset($_COOKIE['CookieLembrete'])) ? $_COOKIE['CookieLembrete'] : '';
@$checked = (@$lembrete == 'SIM') ? 'checked' : '';
@$idempresa = $_SESSION['idempresa'];
@$idcliente = $_SESSION['idcliente'];
if(isset($_SESSION['idcliente'])!=true){echo '<script>location.href="sair.php";</script>'; }
echo'
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>CLIENTE SUPORTE</title>
    <meta name="description" content="MKTOP CLIENTE">
    <meta name="keywords" content="SISTEMA DE ATENDIMENTO AO CLIENTE">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no" name="viewport" />
    <meta name="apple-mobile-web-app-capable" content="yes" />

    <!-- bootstrap 4.3.1 -->
    <link rel="stylesheet" href="css/bootstrap.css">

    <!-- font awesome 6.1.1 -->
    <link rel="stylesheet" href="css/all.min.css"/>

    <script src="js/all.min.js"></script>
    
    <script type="text/javascript" async="" src="js/ga.js"></script>

    <link rel="manifest" href="./manifest.json"/>

    <link rel="preload" href="./app.js" as="script"/>
    
    <link rel="apple-touch-icon" sizes="76x76" href="icons/icons-app/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" href="icons/icons-app/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="152x152" href="icons/icons-app/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="icons/icons-app/apple-touch-icon-180x180.png">
    <link rel="apple-touch-icon" sizes="167x167" href="icons/icons-app/apple-touch-icon-167x167.png">
    <!-- tela splash -->
    <link href="icons/splash/apple_splash_2048.png" sizes="2048x2732" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1668.png" sizes="1668x2224" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1536.png" sizes="1536x2048" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1125.png" sizes="1125x2436" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_1242.png" sizes="1242x2208" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_750.png" sizes="750x1334" rel="apple-touch-startup-image" />
    <link href="icons/splash/apple_splash_640.png" sizes="640x1136" rel="apple-touch-startup-image" />

    <!-- iOS -->
    <link rel="apple-touch-icon" href="icons/icons-app/apple-touch-icon-144x144.png"/>
    <meta name="mobile-web-app-capable" content="yes"/>
    <meta name="mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="mobile-web-app-title" content="MKTOP CLIENTE"/>
    <meta property="og:title" content="Castanhal - Pará - Brasil"/>
    <meta property="og:description" content="MKTOP CLIENTE"/>
    <meta property="og:image" content="icons/icons-app/icon-192x192.png"/>
    <meta property="og:url" content="https://mktop.net/pwa/"/>
    <meta property="og:type" content="website"/>
    <meta name="twitter:creator" property="og:site_name" content="@msulibrary"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:site" content="https://mktop.net/pwa/"/>

    <!-- Favicon icon -->
    <link rel="shortcut icon" type="image/png" href="icons/logo.png">
    <link rel="icon" type="image/png" href="icons/icons-app/icon-96x96.png">
    <link rel="apple-touch-icon" href="icons/icons-app/icon-96x96.png">
    <style>

/*
    @media screen and (min-device-width: 480px) {
        body {
            display: none;
        }
    }*/
      </style>
</head>
<body>
<header class="header" role="banner">
<h3 CLASS="text_header">SUPORTE AO CLIENTE</h3>
</header>
';
?>