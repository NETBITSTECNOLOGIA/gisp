<?php
echo'
    <footer id="myFooter">
        <div class="footer-social">
             <a href="index.php" class="social-icons"><i class="fa fa-circle-left social-icons"></i></a>
        </div>
    </footer>  
 '
?>