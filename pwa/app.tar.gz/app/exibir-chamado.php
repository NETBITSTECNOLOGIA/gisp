<?php
include 'topo.php';
$id = $_GET['id'];
$query0 = mysqli_query($conexao,"SELECT * FROM chamado WHERE id='$id'") or die (mysqli_error($conexao));       
$dd= mysqli_fetch_array($query0);
echo'
<div class="row" style="font-size: 14px; margin: 8px; margin-top: -40px";>
    <div style="margin-top: 4em;" class="col-lg-12">
        <div class="page-header"  style="text-align:center;">
            <h3 style="font-family:bebas;font-size: 2.5em;letter-spacing: 1px; background: #d9d9d9;border-radius: 0.2em;">CHAMADO</h3>
            <div style="text-align:center;">
                <div>
                    <p>'.$id.'</p>
                    <label for="inputDefault">Nº do chamado</label>
                    <input type="text" class="form-control" name="nchamado" value="'.$dd['nchamado'].'" id="inputDefault" readonly/>
                    </div>
                <div>
                    <label for="inputDefault">Tipo</label>
                    <input type="text" class="form-control" name="tipo" value="'.$dd['tipo'].'" id="inputDefault" readonly/>
                </div>
                <div>
                    <label for="inputDefault">SITUAÇÃO</label>
                    <input type="text" class="form-control" name="situcao" value="'.$dd['situacao'].'" id="inputDefault" readonly/>
                </div>
                <div>
                    <label for="inputDefault">Descrição do cliente</label>
                    <textarea rows="4" style="color: red;" class="form-control" name="obs" id="inputDefault" readonly>'.AspasForm($dd['obs']).'</textarea>
                </div>
                <div>
                    <label for="inputDefault">Descrição suporte</label>'; 
                    $query1 = mysqli_query($conexao,"SELECT * FROM log_chamado WHERE nchamado='$dd[nchamado]' ORDER BY id DESC LIMIT 1") or die (mysqli_error($conexao));       
                    $dd2= mysqli_fetch_array($query1); 
                    echo'
                    <textarea rows="4" style="color: red;" class="form-control" placeholder="Sem descrição por enquanto" id="inputDefault" readonly>'.AspasForm(@$dd2['obs']).'</textarea>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <center>
        <footer id="myFooter">
                <div class="footer-social">
                    <a href="chamado.php" class="social-icons"><i class="fa fa-circle-left social-icons"></i></a>
                </div>
        </footer>
        </center>
    </div>
</div>
';
?>